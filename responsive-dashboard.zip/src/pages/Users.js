import React from 'react';
import Table from '../components/Table';

const userData = [
  { Name: 'John', Email: 'john@example.com', Role: 'Admin' },
  { Name: 'Jane', Email: 'jane@example.com', Role: 'User' },
];

const Users = () => {
  return (
    <div>
      <h2>Users</h2>
      <Table data={userData} columns={['Name', 'Email', 'Role']} />
    </div>
  );
};

export default Users;