import React from 'react';
import Table from '../components/Table';

const productData = [
  { Name: 'Laptop', Price: '$1200', Stock: 20 },
  { Name: 'Phone', Price: '$800', Stock: 50 },
];

const Products = () => {
  return (
    <div>
      <h2>Products</h2>
      <Table data={productData} columns={['Name', 'Price', 'Stock']} />
    </div>
  );
};

export default Products;